﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace as86bFinalProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //utilized Data Context to bind data to an object
            //Reason for the binding statements in the WPF is for data context
            //https://www.codeproject.com/Articles/321899/DataContext-in-WPF

            //in the XAML, DataContext is the reason for the Binding statements
            //spread throughout the code
            DataContext = _ball;
            RightPad.DataContext = _rightPad;
            LeftPad.DataContext = _leftPad;
            Ball.DataContext = _ball;

            //Set timer 
            var timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(10);
            timer.Start();
            timer.Tick += _timer_Tick;
        }

        //Angle ball will come in at
        private double _angle = 155;

        //speed of the ball coming in. keep it slower than the pad
        //or that would be really challenging
        private double _speed = 5;

        //speed of the pad. 7 seems good enough for now
        private int _padSpeed = 7;

        //Timer to 
        void _timer_Tick(object sender, EventArgs e)
        {
            if (_ball.Y <= 0)
            {
                _angle = _angle + (180 - 2 * _angle);
            }

            if (_ball.Y >= MainCanvas.ActualHeight - 20)
            {
                _angle = _angle + (180 - 2 * _angle);
            }

            if (CheckCollision() == true)
            {
                ChangeAngle();
                ChangeDirection();
            }

            //getting into some trippy math stuff
            //googled a lot of stackoverflow stuff to try and find these lines :(

            //radians here is used to calculate angle of the ball
            double radians = (Math.PI / 180) * _angle;

            //vector is used to calculate the magnitude and direction of the ball's coordinates
            Vector vector = new Vector { X = Math.Sin(radians), Y = -Math.Cos(radians) };

            //since we are dealing with vectors, we need to have the speed as well as the direction
            _ball.X += vector.X * _speed;
            _ball.Y += vector.Y * _speed;

            //if the ball goes out of bounds,
            if (_ball.X >= 790)
            {
                //up the score of the player on the left by one
                _ball.LeftResult += 1;

                //then reset the ball
                GameReset();
            }

            //same goes for the ball going out of bounds on the right side
            if (_ball.X <= 5)
            {
                _ball.RightResult += 1;
                GameReset();
            }
        }

        //Ball gets reset to certain coorindates when it respawns everytime
        private void GameReset()
        {
            _ball.Y = 210;
            _ball.X = 380;
        }

        //for when the ball hits and will change direction
        private void ChangeAngle()
        {
            if (_ball.MovingRight)
            {
                _angle = 270 - ((_ball.Y + 10) - (_rightPad.YPosition + 40));
            }
            else if (!_ball.MovingRight)
            {
                _angle = 90 + ((_ball.Y + 10) - (_leftPad.YPosition + 40));
            }
        }

        //ball needs to bounce the other way
        private void ChangeDirection()
        {
            if (_ball.MovingRight)
            {
                _ball.MovingRight = false;
            }
            else if (!_ball.MovingRight)
            {
                _ball.MovingRight = true;
            }
        }

        //when the ball makes contact with the 
        private bool CheckCollision()
        {
            //reset everytime to false
            bool collisionResult = false;

            if (_ball.MovingRight)
            {
                collisionResult = _ball.X >= 760 && (_ball.Y > _rightPad.YPosition - 20 && _ball.Y < _rightPad.YPosition + 80);
            }

            if (!_ball.MovingRight)
            {
                collisionResult = _ball.X <= 20 && (_ball.Y > _leftPad.YPosition - 20 && _ball.Y < _leftPad.YPosition + 80);
            }

            return collisionResult;
        }

        readonly Ball _ball = new Ball { X = 380, Y = 210, MovingRight = true };

        readonly Pad _leftPad = new Pad { YPosition = 90 };
        readonly Pad _rightPad = new Pad { YPosition = 70 };


        private void MainWindow_OnKeyDown(object sender, KeyboardEventArgs e)
        {
            if (Keyboard.IsKeyDown(Key.W))
            {
                _leftPad.YPosition -= _padSpeed;
            }
            if (Keyboard.IsKeyDown(Key.S))
            {
                _leftPad.YPosition += _padSpeed;
            }
            if (Keyboard.IsKeyDown(Key.Up))
            {
                _rightPad.YPosition -= _padSpeed;
            }
            if (Keyboard.IsKeyDown(Key.Down))
            {
                _rightPad.YPosition += _padSpeed;
            }

        }
    }
}
